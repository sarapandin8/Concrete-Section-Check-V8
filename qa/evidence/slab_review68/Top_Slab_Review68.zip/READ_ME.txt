SLAB.DESIGN66
Current/ contains checks of the APPLIED project inputs.
Proposal/ is a separately checked bar-spacing proposal, NOT applied reinforcement.
Changing spacing does not increase concrete thickness or invent slab shear steel.
Inspect remaining one-way shear and scope reviews before changing the design.
