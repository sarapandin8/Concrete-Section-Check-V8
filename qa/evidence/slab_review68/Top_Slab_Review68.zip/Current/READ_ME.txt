AASHTO LRFD Ninth Edition (2020).
The imported shell actions are already factored; multiplier=1.0.
Ballast and equivalent train pressure are analysis provenance only.
Each N-M envelope uses both mats and a single concurrent source vector.
Top/bottom identify bending sign; axial-dominant tension is in both.
Minimum/spacing/shear-tie checks are separate; their capacities are not added.
Agreed connection, bearing-end and one-pass peak exclusions remain.
Nxy/Mxy interaction, local D-regions, available anchorage, fatigue and SLS
require their applicable separate checks. No full-deck certificate is issued.
